// Vérifie si l'utilisateur est connecté
document.addEventListener('DOMContentLoaded', () => {
    const authButton = document.getElementById('auth-button');

    // Exemple : changer le texte si connecté (à adapter avec votre système)
    if (localStorage.getItem('userToken')) {
        authButton.textContent = 'Mon compte';
        authButton.href = 'profile.html';
    } else {
        authButton.textContent = 'Se connecter';
        authButton.href = 'login.html';
    }
});
